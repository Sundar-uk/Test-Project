package com.example.testproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText user;
    Button login;
    SharedPreferences shp;
    SharedPreferences.Editor edit;
    String mail;
    List<User> userlist = new ArrayList<>();
    private FirebaseCrashlytics crashlytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        crashlytics = FirebaseCrashlytics.getInstance();

        initView();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mail = user.getText().toString().toLowerCase();
                if (mail.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter Mail.", Toast.LENGTH_SHORT).show();
                } else {
                    getUserData();
                }
            }
        });

    }

    private void initView() {
        user = (EditText) findViewById(R.id.user);
        login = (Button) findViewById(R.id.login);

        shp = getSharedPreferences("UserInfo", MODE_PRIVATE);
        edit = shp.edit();

    }

    private void getUserData() {

        try {
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("users");

            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    userlist.clear();
                    for (DataSnapshot recipeSnapshot : snapshot.getChildren()) {
                        if (mail.equals(recipeSnapshot.getValue(User.class).getMail())) {
                            Log.e("Details", recipeSnapshot.getValue(User.class).getMail());
                            userlist.add(recipeSnapshot.getValue(User.class));
                            User user = userlist.get(0);
                            crashlytics.setCustomKey("DisplayName", user.getName());
                            crashlytics.setCustomKey("Email",  user.getMail());
                            edit.putString("Comments",user.getComments());
                            edit.putString("Company", user.getCompany());
                            edit.putString("Facebook", user.getFacebook());
                            edit.putString("Instagram", user.getInstagram());
                            edit.putString("Mail", user.getMail());
                            edit.putString("Name", user.getName());
                            edit.putString("Profile", user.getProfile());
                            edit.putString("Twitter",user.getTwitter());
                            edit.putString("Youtube", user.getYoutube());
                            edit.apply();

                        }
                    }
                    Log.e("LIST",new Gson().toJson(userlist));
                    if (userlist.size()>0){
                        finishAffinity();
                        startActivity(new Intent(MainActivity.this, UserActivity.class));
                    } else if (userlist.isEmpty() || userlist.equals(null)){
                        Log.e("Toast","Show");
                        Toast.makeText(MainActivity.this, "User is not registered,contact Admin", Toast.LENGTH_SHORT).show();
                        crashlytics.log("Log some message before a crash happen");
                        throw new RuntimeException("User is not registered,contact Admin");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(MainActivity.this, "onCancelled: " + databaseError.getMessage(), Toast.LENGTH_LONG).show();
                }

            });

        } catch (Exception e){
            Log.e("Excep",e.getMessage());
        }


    }

}