package com.example.testproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserActivity extends AppCompatActivity {

    CircleImageView profile_image;
    SharedPreferences shp;
    String profile,namestr,mailstr,companystr,commentsstr;
    TextView name,mail,company;
    EditText comment;
    WebView webview,facebookview,instagramview,twitterview;
    List<String> urllist = new ArrayList<>();
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        initView();

        getValues();

        websettings();

        facebooksettings();

        instagramsettings();

        twittersettings();

        company.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in  = new Intent(Intent.ACTION_VIEW);
                in.setData(Uri.parse(companystr));
                startActivity(in);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commentsstr = comment.getText().toString().trim();
                Log.e("Comment",commentsstr);
                writeData();
            }
        });

    }

    private void twittersettings() {
        final WebSettings settings = twitterview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setPluginState(WebSettings.PluginState.ON);

        twitterview.setWebViewClient(new WebViewClient() {
            // autoplay when finished loading via javascript injection

            public void onPageFinished(WebView view, String url) {
                twitterview.loadUrl("javascript:(function() { document.getElementsByTagName('video')[0].play(); })()");
//                webview.loadUrl(urllist.get(1));
            }

        });

        twitterview.setWebChromeClient(new WebChromeClient());

        twitterview.loadUrl(urllist.get(3));
    }

    private void instagramsettings() {
        final WebSettings settings = instagramview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setPluginState(WebSettings.PluginState.ON);

        instagramview.setWebViewClient(new WebViewClient() {
            // autoplay when finished loading via javascript injection

            public void onPageFinished(WebView view, String url) {
                instagramview.loadUrl("javascript:(function() { document.getElementsByTagName('video')[0].play(); })()");
//                webview.loadUrl(urllist.get(1));
            }

        });

        instagramview.setWebChromeClient(new WebChromeClient());

        instagramview.loadUrl(urllist.get(2));
    }

    private void facebooksettings() {
        final WebSettings settings = facebookview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setPluginState(WebSettings.PluginState.ON);

        facebookview.setWebViewClient(new WebViewClient() {
            // autoplay when finished loading via javascript injection

            public void onPageFinished(WebView view, String url) {
                facebookview.loadUrl("javascript:(function() { document.getElementsByTagName('video')[0].play(); })()");
//                webview.loadUrl(urllist.get(1));
            }

        });

        facebookview.setWebChromeClient(new WebChromeClient());

        facebookview.loadUrl(urllist.get(1));
    }

    private void writeData() {
        try {
            FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
            DatabaseReference reference = firebaseDatabase.getReference().child("users");
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        if (mailstr.equals(dataSnapshot.getValue(User.class).getMail())) {
                            dataSnapshot.getRef().child("comments").setValue(commentsstr);
                            Toast.makeText(UserActivity.this, "Comments are added.", Toast.LENGTH_SHORT).show();
                            finishAffinity();
                            startActivity(new Intent(UserActivity.this, MainActivity.class));
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(UserActivity.this, "The Read failed: " +error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

        } catch (Exception e){
            Log.e("Exception",e.getMessage());
        }

    }

    private void websettings() {
        final WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setPluginState(WebSettings.PluginState.ON);

        webview.setWebViewClient(new WebViewClient() {
            // autoplay when finished loading via javascript injection

            public void onPageFinished(WebView view, String url) {
                webview.loadUrl("javascript:(function() { document.getElementsByTagName('video')[0].play(); })()");
//                webview.loadUrl(urllist.get(1));
            }

        });

        webview.setWebChromeClient(new WebChromeClient());

        webview.loadUrl(urllist.get(0));
    }

    private void getValues() {
        shp = getSharedPreferences("UserInfo",MODE_PRIVATE);

        profile = shp.getString("Profile","");
        namestr = shp.getString("Name","");
        mailstr = shp.getString("Mail","");
        companystr = shp.getString("Company","");
        commentsstr = shp.getString("Comments","");

        urllist.clear();
        urllist.add(shp.getString("Youtube",""));
        urllist.add(shp.getString("Facebook",""));
        urllist.add(shp.getString("Instagram",""));
        urllist.add(shp.getString("Twitter",""));

        Picasso.get().load(profile).into(profile_image);

        name.setText(namestr);
        mail.setText(mailstr);
        company.setText(companystr);
        comment.setText(commentsstr);
    }

    private void initView() {
        webview = (WebView)findViewById(R.id.webview);
        facebookview = (WebView)findViewById(R.id.facebookview);
        instagramview = (WebView)findViewById(R.id.instagramview);
        twitterview = (WebView)findViewById(R.id.twitterview);
        profile_image = (CircleImageView)findViewById(R.id.profile_image);
        name = (TextView)findViewById(R.id.name);
        mail = (TextView)findViewById(R.id.mail);
        company = (TextView)findViewById(R.id.company);
        comment = (EditText)findViewById(R.id.comment);
        submit = (Button)findViewById(R.id.submit);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
        startActivity(new Intent(UserActivity.this,MainActivity.class));
    }
}